//
// Example Stub for Class file for CS 4000, HW #3
//
// To compile: g++ GOL_display.cc -lncurses
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <fstream>
#include <algorithm>
#include <vector>
#include <cctype>
#include <string>
using namespace std;

#ifndef CS4000_GAME_OF_LIFE
#define CS4000_GAME_OF_LIFE

class GameOfLife {
public:
    vector<vector<int> > SimulateLife(vector<vector<int> > &board, int life_cycles);

    //vector<vector<int> > getlife(vector<vector<int> > &board, int life_cycles);

    int checkdir(vector<vector<int> > &board, int life_cycles, int i, int j);
};
#endif

/**
 * Note of Rules: 
 * Cell with 4+ neighbors are alive, the cell will die                                        4+ = Die
 * Cell with exactly 3 neighbors alive, a cell is born                                        3 = Born
 * Cell with 2 or 3 neighbors alive, the cell will survive (if it was alive)                  2 or 3 = Live
 * Cell with 0 or 1 neighbors alive, the cell will die                                        1 or 2 = Die
 * 
 */ 
vector<vector<int> > GameOfLife::SimulateLife(vector<vector<int> > &board, int life_cycles){
    vector<vector<int> > sol = board;
    for(int i = 0; i < life_cycles; i++){
        for(int j = 0; j < life_cycles; j++){
            int numoflife = checkdir(board, life_cycles, i, j);

            if(board[i][j] == 1 && numoflife >= 4)                                                // Die 
                sol[i][j] = 0;
            else if(board[i][j] == 0 && numoflife == 3)                                           // Born
                sol[i][j] = 1;
            else if((board[i][j] == 2 || board[i][j] == 3) && (numoflife == 2 || numoflife == 3)) // Remain the same
                sol[i][j] = board[i][j];
            else if(board[i][j] == 1 && (numoflife == 0 || numoflife == 1))                       // die
                sol[i][j] = 0;
                
        } // end of j
    } // end of i


    // retuns the 2 dimensional gride (1 or 2 -- alive, 0 == dead) after life_Cycles (board size) generations
    // A value of 2 means the cell is immortal 
    return sol;
} // end func

/**
 * Check the 8 given neighbors
 * 0: (i + 1( mod )n, j), 1: (i − 1) mod n, j), 2: (i − 1) mod n, j + 1 mod n), 3: (i − 1) mod n, j − 1 mod n), 
 * 4: (i + 1) mod n, j + 1 mod n), 5: (i + 1) mod n, j − 1 mod n), 6: (i, j + 1 mod n), 7: (i, j − 1 mod n)
 * This function shall return how many pieces are alive on the board
 * This is done by the given 8 directional equations listed above
 */ 
int GameOfLife::checkdir(vector<vector<int> > &board, int life_cycles, int i, int j){
    int lifestatus, row = (life_cycles + i), col = (life_cycles + j);
    for(int k = 0; k <= 7; k++){
        if(k == 0)
            if(board[((row + 1) % life_cycles)][j] == 1 || board[((row + 1) % life_cycles)][j] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 1)
            if(board[((row - 1) % life_cycles)][j] == 1 || board[((row - 1) % life_cycles)][j] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 2)
            if(board[((row - 1) % life_cycles)][((col + 1) % life_cycles)] == 1 || board[((row - 1) % life_cycles)][((col + 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 3)
            if(board[((row - 1) % life_cycles)][((col - 1) % life_cycles)] == 1 || board[((row - 1) % life_cycles)][((col - 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 4)
            if(board[((row + 1) % life_cycles)][((col + 1) % life_cycles)] == 1 || board[((row + 1) % life_cycles)][((col + 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 5)
            if(board[((row + 1) % life_cycles)][((col - 1) % life_cycles)] == 1 || board[((row + 1) % life_cycles)][((col - 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 6)
            if(board[i][((col + 1) % life_cycles)] == 1 || board[i][((col + 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
        if(k == 7)
            if(board[i][((col - 1) % life_cycles)] == 1 || board[i][((col - 1) % life_cycles)] == 2)
                lifestatus++;
//***********************************************************************************************
    } // end of k
    
    return lifestatus;
} // end func
